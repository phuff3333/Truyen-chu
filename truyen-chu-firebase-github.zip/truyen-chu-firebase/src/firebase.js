// Thay YOUR_... bang firebaseConfig trong Firebase Console > Project settings > Your apps.
import {initializeApp} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import {getAuth} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import {getFirestore} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
const firebaseConfig={apiKey:"YOUR_API_KEY",authDomain:"YOUR_PROJECT_ID.firebaseapp.com",projectId:"YOUR_PROJECT_ID",storageBucket:"YOUR_PROJECT_ID.appspot.com",messagingSenderId:"YOUR_MESSAGING_SENDER_ID",appId:"YOUR_APP_ID"};
export const configured=!Object.values(firebaseConfig).some(v=>String(v).startsWith("YOUR_"));
const app=initializeApp(firebaseConfig);export const auth=getAuth(app);export const db=getFirestore(app);
