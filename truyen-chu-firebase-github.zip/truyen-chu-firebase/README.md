# TRUYỆN CHỮ — GitHub Pages + Firebase

Dự án giao diện đọc truyện phong cách tối giản, sang trọng. Có đủ 6 nhóm chức năng:
1. Đăng ký/đăng nhập bằng Firebase Authentication (Email/Password).
2. Thành viên gửi truyện; truyện mới ở trạng thái `pending`.
3. Lưu truyện yêu thích.
4. Theo dõi truyện và lịch sử đọc.
5. Bình luận dưới truyện.
6. Trang quản trị duyệt/từ chối truyện (dựa trên document `admins/{uid}`).

## 1. Cấu hình Firebase (không dùng Supabase)
1. Vào https://console.firebase.google.com → tạo project.
2. Add app dạng Web (`</>`) → copy `firebaseConfig`.
3. Mở `src/firebase.js`, thay các giá trị `YOUR_...` bằng cấu hình dự án.
4. Authentication → Get started → Sign-in method → bật **Email/Password**.
5. Firestore Database → Create database.
6. Tab Rules → dán nội dung file `firestore.rules` → Publish.
7. Không đưa service-account JSON/private key vào website hoặc GitHub. Firebase web config là cấu hình nhận diện ứng dụng; bảo vệ dữ liệu bằng Firestore Rules.

## 2. Cấp quyền admin cho tài khoản của bạn
1. Chạy website và đăng ký tài khoản của bạn.
2. Firebase Console → Authentication → Users → copy User UID của tài khoản.
3. Firestore Database → Start collection → collection ID `admins`.
4. Document ID phải là UID vừa copy; thêm field `role` kiểu string, value `admin`.
5. Đăng xuất rồi đăng nhập lại. Nút **Quản trị** sẽ hiện ra.
Chỉ cấp quyền admin cho tài khoản đáng tin cậy. Rules không cho phép tạo admin từ trình duyệt.

## 3. Chạy thử
Không mở trực tiếp bằng `file://`; hãy dùng web server.
- VS Code + extension Live Server, mở `index.html` bằng Live Server; hoặc
- chạy `python -m http.server 8000`, rồi mở http://localhost:8000.

## 4. Đưa lên GitHub Pages
1. Tạo repository GitHub, ví dụ `truyen-chu`.
2. Upload toàn bộ thư mục và file trong dự án, giữ nguyên cấu trúc.
3. Repository → Settings → Pages → Deploy from a branch.
4. Chọn branch `main`, folder `/ (root)` → Save.
5. Đợi GitHub Pages cấp URL dạng `https://TEN-USER.github.io/truyen-chu/`.
6. Firebase Console → Authentication → Settings → Authorized domains → thêm `TEN-USER.github.io` (và domain riêng nếu có).

## 5. Dữ liệu và vận hành
- Truyện mẫu trong trang chỉ để xem giao diện; tính năng lưu/bình luận áp dụng cho truyện đã đăng trên Firestore.
- Bài thành viên gửi sẽ chờ admin duyệt rồi mới công khai.
- Firestore Rules giới hạn người dùng chỉ sửa dữ liệu cá nhân của họ; admin được duyệt truyện.
- Theo dõi Firebase Usage & billing; hạn mức miễn phí và điều kiện thanh toán có thể thay đổi.
- Trước khi mở rộng cộng đồng, nên thêm báo cáo nội dung, chống spam/rate-limit, quy trình xóa tài khoản và chính sách quyền riêng tư. Với cộng đồng lớn, chuyển thao tác nhạy cảm sang backend/Cloud Functions.
- Bản này chưa tự đăng code lên GitHub hay tạo Firebase project; bạn cần thực hiện các bước cấu hình ở trên.

## Cấu trúc
```text
truyen-chu-firebase/
├── index.html
├── firestore.rules
├── README.md
└── src/
    ├── app.js
    ├── firebase.js
    └── style.css
```
